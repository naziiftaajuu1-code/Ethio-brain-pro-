package com.example

import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyApplicationTheme {
                // BuildConfig.GEMINI_API_KEY automatically reads securely from your .env file
                WebViewScreen(BuildConfig.GEMINI_API_KEY) 
            }
        }
    }
}

class WebAppInterface(private val apiKey: String, private val webView: WebView) {
    @JavascriptInterface
    fun callGemini(prompt: String, callbackId: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val request = GenerateContentRequest(
                    contents = listOf(Content(parts = listOf(Part(text = prompt))))
                )
                val response = GeminiService.api.generateContent(apiKey, request)
                val reply = response.candidates.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: ""
                
                // Route the response back safely into the HTML runtime environment
                withContext(Dispatchers.Main) {
                    val safeReply = reply.replace("`", "\\`").replace("$", "\\$")
                    webView.evaluateJavascript("window.handleGeminiResponse('$callbackId', `$safeReply`, null);", null)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    webView.evaluateJavascript("window.handleGeminiResponse('$callbackId', null, '${e.message}');", null)
                }
            }
        }
    }
}

@Composable
fun WebViewScreen(apiKey: String) {
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { context ->
            WebView(context).apply {
                settings.javaScriptEnabled = true
                webViewClient = WebViewClient()
                
                // Creating the 'AndroidBridge' runtime object accessible inside JavaScript
                addJavascriptInterface(WebAppInterface(apiKey, this), "AndroidBridge")
                
                loadUrl("file:///android_asset/index.html")
            }
        }
    )
}
